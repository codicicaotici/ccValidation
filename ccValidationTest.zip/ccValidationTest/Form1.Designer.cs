﻿
namespace ccValidationTest
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_login = new System.Windows.Forms.Label();
            this.lb_alpha = new System.Windows.Forms.Label();
            this.lb_alphanum = new System.Windows.Forms.Label();
            this.lb_all = new System.Windows.Forms.Label();
            this.lb_cap = new System.Windows.Forms.Label();
            this.lb_zip = new System.Windows.Forms.Label();
            this.txt_login = new System.Windows.Forms.TextBox();
            this.txt_alpha = new System.Windows.Forms.TextBox();
            this.txt_alphanum = new System.Windows.Forms.TextBox();
            this.txt_all = new System.Windows.Forms.TextBox();
            this.txt_cap = new System.Windows.Forms.TextBox();
            this.txt_zip = new System.Windows.Forms.TextBox();
            this.btn_close = new System.Windows.Forms.Button();
            this.btn_test = new System.Windows.Forms.Button();
            this.lb_phone = new System.Windows.Forms.Label();
            this.lb_integer = new System.Windows.Forms.Label();
            this.lb_decimal = new System.Windows.Forms.Label();
            this.lb_currency = new System.Windows.Forms.Label();
            this.lb_email = new System.Windows.Forms.Label();
            this.lb_url = new System.Windows.Forms.Label();
            this.lb_date = new System.Windows.Forms.Label();
            this.txt_phone = new System.Windows.Forms.TextBox();
            this.txt_integer = new System.Windows.Forms.TextBox();
            this.txt_decimal = new System.Windows.Forms.TextBox();
            this.txt_currency = new System.Windows.Forms.TextBox();
            this.txt_email = new System.Windows.Forms.TextBox();
            this.txt_url = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_fill1 = new System.Windows.Forms.Button();
            this.btn_fill2 = new System.Windows.Forms.Button();
            this.btn_clear = new System.Windows.Forms.Button();
            this.txt_date = new System.Windows.Forms.DateTimePicker();
            this.lb_custom = new System.Windows.Forms.Label();
            this.txt_custom = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lb_login
            // 
            this.lb_login.AutoSize = true;
            this.lb_login.Location = new System.Drawing.Point(30, 87);
            this.lb_login.Name = "lb_login";
            this.lb_login.Size = new System.Drawing.Size(29, 13);
            this.lb_login.TabIndex = 0;
            this.lb_login.Text = "login";
            // 
            // lb_alpha
            // 
            this.lb_alpha.AutoSize = true;
            this.lb_alpha.Location = new System.Drawing.Point(30, 117);
            this.lb_alpha.Name = "lb_alpha";
            this.lb_alpha.Size = new System.Drawing.Size(33, 13);
            this.lb_alpha.TabIndex = 1;
            this.lb_alpha.Text = "alpha";
            // 
            // lb_alphanum
            // 
            this.lb_alphanum.AutoSize = true;
            this.lb_alphanum.Location = new System.Drawing.Point(30, 147);
            this.lb_alphanum.Name = "lb_alphanum";
            this.lb_alphanum.Size = new System.Drawing.Size(56, 13);
            this.lb_alphanum.TabIndex = 2;
            this.lb_alphanum.Text = "alpha num";
            // 
            // lb_all
            // 
            this.lb_all.AutoSize = true;
            this.lb_all.Location = new System.Drawing.Point(30, 177);
            this.lb_all.Name = "lb_all";
            this.lb_all.Size = new System.Drawing.Size(17, 13);
            this.lb_all.TabIndex = 3;
            this.lb_all.Text = "all";
            // 
            // lb_cap
            // 
            this.lb_cap.AutoSize = true;
            this.lb_cap.Location = new System.Drawing.Point(30, 207);
            this.lb_cap.Name = "lb_cap";
            this.lb_cap.Size = new System.Drawing.Size(25, 13);
            this.lb_cap.TabIndex = 4;
            this.lb_cap.Text = "cap";
            // 
            // lb_zip
            // 
            this.lb_zip.AutoSize = true;
            this.lb_zip.Location = new System.Drawing.Point(30, 237);
            this.lb_zip.Name = "lb_zip";
            this.lb_zip.Size = new System.Drawing.Size(20, 13);
            this.lb_zip.TabIndex = 5;
            this.lb_zip.Text = "zip";
            // 
            // txt_login
            // 
            this.txt_login.Location = new System.Drawing.Point(139, 81);
            this.txt_login.Name = "txt_login";
            this.txt_login.Size = new System.Drawing.Size(176, 20);
            this.txt_login.TabIndex = 6;
            // 
            // txt_alpha
            // 
            this.txt_alpha.Location = new System.Drawing.Point(139, 112);
            this.txt_alpha.Name = "txt_alpha";
            this.txt_alpha.Size = new System.Drawing.Size(176, 20);
            this.txt_alpha.TabIndex = 7;
            // 
            // txt_alphanum
            // 
            this.txt_alphanum.Location = new System.Drawing.Point(139, 143);
            this.txt_alphanum.Name = "txt_alphanum";
            this.txt_alphanum.Size = new System.Drawing.Size(176, 20);
            this.txt_alphanum.TabIndex = 8;
            // 
            // txt_all
            // 
            this.txt_all.Location = new System.Drawing.Point(139, 174);
            this.txt_all.Name = "txt_all";
            this.txt_all.Size = new System.Drawing.Size(176, 20);
            this.txt_all.TabIndex = 9;
            // 
            // txt_cap
            // 
            this.txt_cap.Location = new System.Drawing.Point(139, 205);
            this.txt_cap.Name = "txt_cap";
            this.txt_cap.Size = new System.Drawing.Size(176, 20);
            this.txt_cap.TabIndex = 10;
            // 
            // txt_zip
            // 
            this.txt_zip.Location = new System.Drawing.Point(139, 236);
            this.txt_zip.Name = "txt_zip";
            this.txt_zip.Size = new System.Drawing.Size(176, 20);
            this.txt_zip.TabIndex = 11;
            // 
            // btn_close
            // 
            this.btn_close.Location = new System.Drawing.Point(337, 518);
            this.btn_close.Name = "btn_close";
            this.btn_close.Size = new System.Drawing.Size(55, 34);
            this.btn_close.TabIndex = 12;
            this.btn_close.Text = "Close";
            this.btn_close.UseVisualStyleBackColor = true;
            this.btn_close.Click += new System.EventHandler(this.btn_close_Click);
            // 
            // btn_test
            // 
            this.btn_test.Location = new System.Drawing.Point(213, 518);
            this.btn_test.Name = "btn_test";
            this.btn_test.Size = new System.Drawing.Size(102, 34);
            this.btn_test.TabIndex = 13;
            this.btn_test.Text = "Test";
            this.btn_test.UseVisualStyleBackColor = true;
            this.btn_test.Click += new System.EventHandler(this.btn_test_Click);
            // 
            // lb_phone
            // 
            this.lb_phone.AutoSize = true;
            this.lb_phone.Location = new System.Drawing.Point(30, 267);
            this.lb_phone.Name = "lb_phone";
            this.lb_phone.Size = new System.Drawing.Size(37, 13);
            this.lb_phone.TabIndex = 14;
            this.lb_phone.Text = "phone";
            // 
            // lb_integer
            // 
            this.lb_integer.AutoSize = true;
            this.lb_integer.Location = new System.Drawing.Point(30, 297);
            this.lb_integer.Name = "lb_integer";
            this.lb_integer.Size = new System.Drawing.Size(39, 13);
            this.lb_integer.TabIndex = 15;
            this.lb_integer.Text = "integer";
            // 
            // lb_decimal
            // 
            this.lb_decimal.AutoSize = true;
            this.lb_decimal.Location = new System.Drawing.Point(30, 327);
            this.lb_decimal.Name = "lb_decimal";
            this.lb_decimal.Size = new System.Drawing.Size(43, 13);
            this.lb_decimal.TabIndex = 16;
            this.lb_decimal.Text = "decimal";
            // 
            // lb_currency
            // 
            this.lb_currency.AutoSize = true;
            this.lb_currency.Location = new System.Drawing.Point(28, 357);
            this.lb_currency.Name = "lb_currency";
            this.lb_currency.Size = new System.Drawing.Size(48, 13);
            this.lb_currency.TabIndex = 17;
            this.lb_currency.Text = "currency";
            // 
            // lb_email
            // 
            this.lb_email.AutoSize = true;
            this.lb_email.Location = new System.Drawing.Point(30, 387);
            this.lb_email.Name = "lb_email";
            this.lb_email.Size = new System.Drawing.Size(31, 13);
            this.lb_email.TabIndex = 18;
            this.lb_email.Text = "email";
            // 
            // lb_url
            // 
            this.lb_url.AutoSize = true;
            this.lb_url.Location = new System.Drawing.Point(28, 417);
            this.lb_url.Name = "lb_url";
            this.lb_url.Size = new System.Drawing.Size(18, 13);
            this.lb_url.TabIndex = 19;
            this.lb_url.Text = "url";
            // 
            // lb_date
            // 
            this.lb_date.AutoSize = true;
            this.lb_date.Location = new System.Drawing.Point(26, 447);
            this.lb_date.Name = "lb_date";
            this.lb_date.Size = new System.Drawing.Size(50, 13);
            this.lb_date.TabIndex = 20;
            this.lb_date.Text = "data time";
            // 
            // txt_phone
            // 
            this.txt_phone.Location = new System.Drawing.Point(139, 264);
            this.txt_phone.Name = "txt_phone";
            this.txt_phone.Size = new System.Drawing.Size(176, 20);
            this.txt_phone.TabIndex = 21;
            // 
            // txt_integer
            // 
            this.txt_integer.Location = new System.Drawing.Point(139, 291);
            this.txt_integer.Name = "txt_integer";
            this.txt_integer.Size = new System.Drawing.Size(176, 20);
            this.txt_integer.TabIndex = 22;
            // 
            // txt_decimal
            // 
            this.txt_decimal.Location = new System.Drawing.Point(139, 324);
            this.txt_decimal.Name = "txt_decimal";
            this.txt_decimal.Size = new System.Drawing.Size(176, 20);
            this.txt_decimal.TabIndex = 23;
            // 
            // txt_currency
            // 
            this.txt_currency.Location = new System.Drawing.Point(139, 354);
            this.txt_currency.Name = "txt_currency";
            this.txt_currency.Size = new System.Drawing.Size(176, 20);
            this.txt_currency.TabIndex = 24;
            // 
            // txt_email
            // 
            this.txt_email.Location = new System.Drawing.Point(139, 384);
            this.txt_email.Name = "txt_email";
            this.txt_email.Size = new System.Drawing.Size(176, 20);
            this.txt_email.TabIndex = 25;
            // 
            // txt_url
            // 
            this.txt_url.Location = new System.Drawing.Point(139, 414);
            this.txt_url.Name = "txt_url";
            this.txt_url.Size = new System.Drawing.Size(176, 20);
            this.txt_url.TabIndex = 26;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(334, 84);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(45, 13);
            this.label14.TabIndex = 28;
            this.label14.Text = "required";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(334, 207);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(63, 13);
            this.label15.TabIndex = 29;
            this.label15.Text = "min 5 max 5";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(124, 13);
            this.label1.TabIndex = 30;
            this.label1.Text = "codicicaotici@gmail.com";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(26, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(139, 13);
            this.label2.TabIndex = 31;
            this.label2.Text = "ccValidation - text validation";
            // 
            // btn_fill1
            // 
            this.btn_fill1.Location = new System.Drawing.Point(26, 518);
            this.btn_fill1.Name = "btn_fill1";
            this.btn_fill1.Size = new System.Drawing.Size(50, 34);
            this.btn_fill1.TabIndex = 32;
            this.btn_fill1.Text = "Fill 1";
            this.btn_fill1.UseVisualStyleBackColor = true;
            this.btn_fill1.Click += new System.EventHandler(this.btn_fill1_Click);
            // 
            // btn_fill2
            // 
            this.btn_fill2.Location = new System.Drawing.Point(82, 518);
            this.btn_fill2.Name = "btn_fill2";
            this.btn_fill2.Size = new System.Drawing.Size(50, 34);
            this.btn_fill2.TabIndex = 33;
            this.btn_fill2.Text = "Fill 2";
            this.btn_fill2.UseVisualStyleBackColor = true;
            this.btn_fill2.Click += new System.EventHandler(this.btn_fill2_Click);
            // 
            // btn_clear
            // 
            this.btn_clear.Location = new System.Drawing.Point(139, 518);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(50, 34);
            this.btn_clear.TabIndex = 34;
            this.btn_clear.Text = "Clear";
            this.btn_clear.UseVisualStyleBackColor = true;
            this.btn_clear.Click += new System.EventHandler(this.btn_clear_Click);
            // 
            // txt_date
            // 
            this.txt_date.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txt_date.Location = new System.Drawing.Point(139, 441);
            this.txt_date.Name = "txt_date";
            this.txt_date.Size = new System.Drawing.Size(176, 20);
            this.txt_date.TabIndex = 35;
            // 
            // lb_custom
            // 
            this.lb_custom.AutoSize = true;
            this.lb_custom.Location = new System.Drawing.Point(28, 478);
            this.lb_custom.Name = "lb_custom";
            this.lb_custom.Size = new System.Drawing.Size(42, 13);
            this.lb_custom.TabIndex = 36;
            this.lb_custom.Text = "Custom";
            // 
            // txt_custom
            // 
            this.txt_custom.Location = new System.Drawing.Point(139, 471);
            this.txt_custom.Name = "txt_custom";
            this.txt_custom.Size = new System.Drawing.Size(176, 20);
            this.txt_custom.TabIndex = 37;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(335, 474);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 13);
            this.label3.TabIndex = 38;
            this.label3.Text = "like \'zip\'";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(425, 583);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txt_custom);
            this.Controls.Add(this.lb_custom);
            this.Controls.Add(this.txt_date);
            this.Controls.Add(this.btn_clear);
            this.Controls.Add(this.btn_fill2);
            this.Controls.Add(this.btn_fill1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txt_url);
            this.Controls.Add(this.txt_email);
            this.Controls.Add(this.txt_currency);
            this.Controls.Add(this.txt_decimal);
            this.Controls.Add(this.txt_integer);
            this.Controls.Add(this.txt_phone);
            this.Controls.Add(this.lb_date);
            this.Controls.Add(this.lb_url);
            this.Controls.Add(this.lb_email);
            this.Controls.Add(this.lb_currency);
            this.Controls.Add(this.lb_decimal);
            this.Controls.Add(this.lb_integer);
            this.Controls.Add(this.lb_phone);
            this.Controls.Add(this.btn_test);
            this.Controls.Add(this.btn_close);
            this.Controls.Add(this.txt_zip);
            this.Controls.Add(this.txt_cap);
            this.Controls.Add(this.txt_all);
            this.Controls.Add(this.txt_alphanum);
            this.Controls.Add(this.txt_alpha);
            this.Controls.Add(this.txt_login);
            this.Controls.Add(this.lb_zip);
            this.Controls.Add(this.lb_cap);
            this.Controls.Add(this.lb_all);
            this.Controls.Add(this.lb_alphanum);
            this.Controls.Add(this.lb_alpha);
            this.Controls.Add(this.lb_login);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ccValidation";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_login;
        private System.Windows.Forms.Label lb_alpha;
        private System.Windows.Forms.Label lb_alphanum;
        private System.Windows.Forms.Label lb_all;
        private System.Windows.Forms.Label lb_cap;
        private System.Windows.Forms.Label lb_zip;
        private System.Windows.Forms.TextBox txt_login;
        private System.Windows.Forms.TextBox txt_alpha;
        private System.Windows.Forms.TextBox txt_alphanum;
        private System.Windows.Forms.TextBox txt_all;
        private System.Windows.Forms.TextBox txt_cap;
        private System.Windows.Forms.TextBox txt_zip;
        private System.Windows.Forms.Button btn_close;
        private System.Windows.Forms.Button btn_test;
        private System.Windows.Forms.Label lb_phone;
        private System.Windows.Forms.Label lb_integer;
        private System.Windows.Forms.Label lb_decimal;
        private System.Windows.Forms.Label lb_currency;
        private System.Windows.Forms.Label lb_email;
        private System.Windows.Forms.Label lb_url;
        private System.Windows.Forms.Label lb_date;
        private System.Windows.Forms.TextBox txt_phone;
        private System.Windows.Forms.TextBox txt_integer;
        private System.Windows.Forms.TextBox txt_decimal;
        private System.Windows.Forms.TextBox txt_currency;
        private System.Windows.Forms.TextBox txt_email;
        private System.Windows.Forms.TextBox txt_url;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_fill1;
        private System.Windows.Forms.Button btn_fill2;
        private System.Windows.Forms.Button btn_clear;
        private System.Windows.Forms.DateTimePicker txt_date;
        private System.Windows.Forms.Label lb_custom;
        private System.Windows.Forms.TextBox txt_custom;
        private System.Windows.Forms.Label label3;
    }
}

